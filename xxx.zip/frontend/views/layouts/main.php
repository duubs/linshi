<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<base href="index/" />
<head>

    <!-- Basic Page Needs
  ================================================== -->
    <meta charset="utf-8">
    <title>zSoccer</title>
    <meta name="description" content="">
    
    
    <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    
    <!-- CSS
  ================================================== -->
    <link rel="stylesheet" href="css/zerogrid.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <script src="js/jquery-latest.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/jquery183.min.js"></script>
    <script src="js/responsiveslides.min.js"></script>
    <script>
        // You can also use "$(window).load(function() {"
        $(function () {
          // Slideshow 
          $("#slider").responsiveSlides({
            auto: true,
            pager: false,
            nav: true,
            speed: 500,
            namespace: "callbacks",
            before: function () {
              $('.events').append("<li>before event fired.</li>");
            },
            after: function () {
              $('.events').append("<li>after event fired.</li>");
            }
          });
        });
    </script>
    
    
    <!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
        <script src="js/html5.js"></script>
        <script src="js/css3-mediaqueries.js"></script>
    <![endif]-->
    
</head>
<body>
<div class="wrap-body">

<!-- /////////////////////////////////////////Top -->
<div class="top">
    <div class="zerogrid">
        <div class="row">
            <div class="f-left">
                <span><i class="fa fa-map-marker"></i> 北京, 海淀 10036, 中国 </span>
                <span><i class="fa fa-phone"></i> 155-0105-7027; 132-6181-6219</span>
                <span><i class="fa fa-envelope"></i>15501057027@163.com</span>
            </div>
            <div class="f-right">
                <span>生命在于运动，生命不可停息。</span>
            </div>
        </div>
    </div>
</div>

<!--////////////////////////////////////Header-->
<header>
    <div class="wrap-header zerogrid">
        <div class="row">
            <div id="cssmenu">
                <ul>
                   <li class='active'><a href="../index.php?r=index/index">首页</a></li>
                   <li><a href="../index.php?r=index/archive">文章</a></li>
                   <li><a href="../index.php?r=index/single">关于</a></li>
                   <li><a href="../index.php?r=index/contact">联系我们</a></li>
                </ul>
            </div>
           <img src="images/logo.png" />
        </div>
    </div>
</header>
<div class="bg-white">
    <div class="zerogrid">
        <!-- Slideshow -->
        <div class="callbacks_container">
            <ul class="rslides" id="slider">
                <li>
                    <img src="images/slideshow-image1.jpg" alt="">
                    <div class="caption">
                        <h1>欢迎来到前沿</h1>
                        <span >测试网站</span>
                    </div>
                </li>
                <li>
                    <img src="images/slideshow-image2.jpg" alt="">
                    <div class="caption">
                      <h1>欢迎来到前沿</h1>
                        <span >测试网站</span>
                    </div>
                </li>
                <li>
                    <img src="images/slideshow-image3.jpg" alt="">
                    <div class="caption">
                      <h1>欢迎来到前沿</h1>
                        <span >测试网站</span>
                    </div>
                </li>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
</div>








<?php echo  $content?>






<footer>
    <div class="zerogrid top-footer">
        <div class="row">
            <div class="col-1-5">
                <img src="images/15.jpg" />
            </div>
            <div class="col-1-5">
                <img src="images/16.jpg" />
            </div>
            <div class="col-1-5">
                <img src="images/17.jpg" />
            </div>
            <div class="col-1-5">
                <img src="images/18.jpg" />
            </div>
            <div class="col-1-5">
                <img src="images/19.jpg" />
            </div>
        </div>
    </div>
    <div class="zerogrid wrap-footer">
        <div class="row">
            <div class="col-1-4 col-footer-1">
                <div class="wrap-col">
                    <h3>关于我们</h3>
                    <p>运动员身上拼搏、进取，坚持到底，永不放弃的精神；指的是“友谊第一、比赛第二”的精神；指的是在运动场上所体现出的宽容、谦让、和谐的竞技精神……在任何一场竞技体育比赛中，体育精神都是至关重要的，尤其是在国际比赛中，体育精神不仅体现出了个人的素养，也代表了一个国家的形象和国民的素质。</p>
                    <img src="images/logo.png" />
                </div>
            </div>
            <div class="col-1-4 col-footer-2">
                <div class="wrap-col">
                    <h3>分类</h3>
                    <ul>
                        <li>特色新闻</li>
                        <li>即将举行的活动</li>
                        <li>即将举行的游戏</li>
                        <li>最新帖子</li>
                        <li>画廊</li>

                    </ul>
                </div>
            </div>
            <div class="col-1-4 col-footer-3">
                <div class="wrap-col">
                    <h3>图片</h3>
                    <div class="row">
                        <div class="col-1-3">
                            <div class="wrap-col">
                                <img src="images/6.jpg" />
                                <img src="images/7.jpg" />
                                <img src="images/8.jpg" />
                            </div>
                        </div>
                        <div class="col-1-3">
                            <div class="wrap-col">
                                <img src="images/9.jpg" /></a>
                                <img src="images/6.jpg" /></a>
                                <img src="images/7.jpg" /></a>
                            </div>
                        </div>
                        <div class="col-1-3">
                            <div class="wrap-col">
                                <img src="images/6.jpg" />
                               <img src="images/7.jpg" />
                                <img src="images/8.jpg" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-1-4 col-footer-4">
                <div class="wrap-col">
                    <h3>联系</h3>
                    <span><i class="fa fa-envelope"></i> www.dxuubb.com</span>
                    <span><i class="fa fa-phone"></i> 155-0105-7027; 132-6181-6219</span>
                    <span><i class="fa fa-map-marker"></i> 海淀区，中关村，中国</span>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="copyright">
    <div class="zerogrid wrapper">
        Copyright &copy; 2016.Company name All rights reserved.More Templates <a href="http://www.cssmoban.com/" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="http://www.cssmoban.com/" title="网页模板" target="_blank">网页模板</a>
        <ul class="quick-link">
            <li>Privacy Policy</li>
            <li>Terms of Use</li>
        </ul>
    </div>
</div>

</div>
</body></html>