<?php 
         use yii\helpers\Url;
 ?>
<!--////////////////////////////////////Container-->
<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div id="main-content" class="col-2-3">
			<div class="wrap-col">
				<div class="wrap-content">
			<?php foreach ($content as $key => $value): ?>
				<?php if ($value['c_id']=='9'): ?>
					<?php if ($value['is_delete']=='0'): ?>		
					<article>
						<div class="art-header">
							
							<img src=<?php echo $value['img_url'] ?> />
						</div>
						<div class="art-content">
							<font color="black"><h3><?php echo $value['title'] ?></h3></font>
							<div class="info">发布于<?php echo $value['datatime'] ?> 在: <a href="#">前沿</a>, <a href="#">新闻</a></div>
							<p><?php echo substr($value['content'],0,400) ?>....</p>
							<a  href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><span><font color="blue">阅读</font>	</span></a>
						</div>
					</article>

					<?php endif ?>
				<?php endif ?>
			<?php endforeach ?>
				</div>
			</div>
		</div>
		<div id="sidebar" class="col-1-3">
			<div class="wrap-col">
				<div class="wrap-sidebar">
					<!---- Start Widget ---->
					<div class="widget wid-about">
						<div class="wid-header">
							<h5>关于我们</h5>
						</div>
						<div class="wid-content">
							<img src="images/15.jpg"/>
							<p>　如果，十年之后，我们还会不会是朋友，再聚也许会哭、笑，至少，我们回忆中，有快乐的时光，不快乐的时光。我们无可阻挡，一起过五关、斩六将，有快乐的时光、不快乐的时光……”每次哼起这首歌，我的眼眶总是不禁有点湿润，我的心中总是充满着不舍，不舍我们这段初中时光。</p>
						</div>
					</div>
					<!---- Start Widget ---->
					<div class="widget wid-post">
						<div class="wid-header">
							<h5>最新帖子</h5>
						</div>
						<div class="wid-content">

				<?php foreach ($content as $key => $value): ?>
					<?php if ($value['c_id']=='6'): ?>
						<?php if ($value['is_delete']=='0'): ?>
							<div class="post">
								<img src=<?php echo $value['img_url'] ?> >
								<div class="wrapper">
								  <h5><a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><?php echo substr($value['title'],0,30) ?></a></h5>
								   <span>$25 - $26</span>
								</div>
							</div>
							
						<?php endif ?>
					<?php endif ?>
				<?php endforeach ?>				
						</div>
					</div>
					<!---- Start Widget ---->
					<div class="widget wid-gallery">
						<div class="wid-header">
							<h5>画廊</h5>
						</div>
						<div class="wid-content">
					<?php foreach ($content as $key => $value): ?>
						<?php if ($value['c_id']=='7'): ?>
							<?php if ($value['is_delete']=='0'): ?>				
								<a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><img src=<?php echo $value['img_url'] ?>></a>
							<?php endif ?>
						<?php endif ?>
					<?php endforeach ?>			
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

