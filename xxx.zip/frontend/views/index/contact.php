 <?php 
         use yii\helpers\Url;
 ?>


<!--////////////////////////////////////Container-->
<section id="container">
	<div class="zerogrid">
		<div class="wrap-container clearfix">
			<div id="main-content">
				<div class="wrap-box"><!--Start Box-->
					<div class="row">
						<div class="col-2-3">
							<div class="wrap-col">
								<div class="contact">
									<div class="contact-header">
										<h5>联系表</h5>
									</div>
									<div id="contact_form">
										<form name="form1" id="ff" method="post" action="<?php echo Url::to(['index/addcontact']) ?>">
											<label class="row">
												<div class="col-1-2">
													<div class="wrap-col">
														<input type="text" name="name" id="name" placeholder="Enter name" required="required" />
													</div>
												</div>
												<div class="col-1-2">
													<div class="wrap-col">
														<input type="email" name="email" id="email" placeholder="Enter email" required="required" />
													</div>
												</div>
											</label>
											
											<label class="row">
												<div class="wrap-col">
													<textarea name="content" id="message" class="form-control" rows="4" cols="25" required="required"
													placeholder="Message"></textarea>
												</div>
											</label>
											<center><input class="sendButton" type="submit" name="submitcontact" value="提交"></center>
										</form>
									</div>
								</div>
							</div>
						</div>
						<div class="col-1-3">
							<div class="wrap-col">
								<div class="contact-header">
									<h5>联系信息</h5>
								</div>
								<div style="background: #fff; padding: 20px; box-shadow: 2px 2px 5px 0px rgba(0,0,0,0.3);">
									<p style="font-size: 20px"><span><font color="blue">公司地址：</font></span>www.dxuubb.top <br>
									<span><font color="blue">公司名称：</font></span>前沿（北京）科技创业有限公司<br>
									<span><font color="blue">客服中心：</font></span>010-822096888（24小时服务）<br>
									<span><font color="blue">24小时咨询热线：</font></span>15035101602<br>
									<span><font color="blue">公司地址：</font></span>北京市海淀区</p>
									<span><font color="blue">Email：</font></span>15501057027@163.com</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!--////////////////////////////////////Footer-->
