 <?php 
         use yii\helpers\Url;
 ?>
<!--////////////////////////////////////Container-->
<section id="container" class="home-page">
	<div class="wrap-container clearfix">
		<div id="main-content">
			<section class="content-box box-1 box-style-1"><!--Start Box-->
				<div class="wrap-box">
					<div class="zerogrid">
						<div class="row">
							<div class="col-1-3">
								<div class="wrap-col">
									<div class="sub-title">
										<h2>特色新闻</h2>
									</div>
									<div class="item">
										
					<?php foreach ($content as $key => $value): ?>
							<?php if ($value['c_id']=='1'): ?>
								<?php if ($value['is_delete']=='0'): ?>
									<img src=<?php echo $value['img_url'] ?> />
										<div class="item-content">
													<h3><font color="black"><?php echo $value['title'] ?></font>	</h3>
													<div class="info">发布于<?php echo $value['datatime'] ?> 在: <a href="#">特色</a>, <a href="#">新闻</a></div>
											<p><?php echo substr($value['content'],0,201) ?>....</p>
											<a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><span><font color="blue">阅读</font>	</span></a>
								<?php endif ?>
							<?php endif ?>
					<?php endforeach ?>
											
											
										</div>
									</div>
								</div>
							</div>
							<div class="col-1-3">
								<div class="wrap-col">
									<div class="sub-title">
										<h2>即将举行的活动</h2>
									</div>
									
					<?php foreach ($content as $key => $value): ?>
							<?php if ($value['c_id']=='2'): ?>
								<?php if ($value['is_delete']=='0'): ?>
									<div class="row">
										<div class="item">
											<div class="item-content">
												<h3><font color="black"><?php echo $value['title'] ?></font>	</h3>
												<div class="info">发布于<?php echo $value['datatime'] ?> 在: <a href="#">即将举行的</a>, <a href="#">活动</a></div>
												<p><?php echo substr($value['content'],0,200) ?>....</p>
												<a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><span><font color="blue">阅读</font>	</span></a>
												</div>
										</div>
									</div>
									<?php endif ?>
							<?php endif ?>
					<?php endforeach ?>
											
								
									
								</div>
							</div>
							<div class="col-1-3">
								<div class="wrap-col">
									<div class="sub-title">
										<h2>即将举行的游戏</h2>
									</div>
						<?php foreach ($content as $key => $value): ?>
							<?php if ($value['c_id']=='3'): ?>
								<?php if ($value['is_delete']=='0'): ?>	
									<h2 style="font-size: 35px;line-height: 1.3;margin-bottom: 10px;"><?php echo $value['title'] ?></h2>
									<img src=<?php echo $value['img_url'] ?> />
									<p><?php echo substr($value['content'],0,200) ?>....</p>
									<!-- <a href="#">查看此馆的所有活动</a><br> -->
									<a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>" class="button bt1">查看</a>
								<?php endif ?>
							<?php endif ?>
						<?php endforeach ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
			<section class="content-box box-2 box-style-3"><!--Start Box-->
				<div class="wrap-box">
					<div class="zerogrid">
						<div class="title">
							<h2><span>我们的</span> 团队</h2>
						</div>	
						<div class="row">
						<?php foreach ($content as $key => $value): ?>
							<?php if ($value['c_id']=='4'): ?>
								<?php if ($value['is_delete']=='0'): ?>
									<div class="col-1-4">
										<div class="wrap-col">
											<div class="item t-center">
												<div class="item-container">
													<a href="single.html">
														<div class="item-caption">
															<div class="item-caption-inner">
																<div class="item-caption-inner1">
																	<span class="user-social"><i class="fa fa-facebook"></i><i class="fa fa-twitter"></i><i class="fa fa-google-plus"></i><i class="fa fa-pinterest"></i></span>
																</div>
															</div>
														</div>
														<img src=<?php echo $value['img_url'] ?> />
													</a>
												</div>
												<div class="item-content">
													<font color="black"><h3><?php echo $value['title'] ?></h3></font>
													<p><?php echo $value['content'] ?></p>
												</div>
											</div>
										</div>
									</div>
							
								<?php endif ?>
							<?php endif ?>
						<?php endforeach ?>
						</div>
					</div>
				</div>
			</section>
			<section class="content-box box-3 box-style-2"><!--Start Box-->
				<div class="wrap-box t-center">
					<div class="zerogrid">
						<div class="title">
							<h2>欢迎 <span>来到我们的网站</span></h2>
						</div>	
						<strong>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</strong>
						<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo</p>
						<a href="../index.php?r=index/details">阅读</a>
					</div>
				</div>
			</section>
			<section class="content-box box-4 box-style-1"><!--Start Box-->
				<div class="wrap-box" >
					<div class="zerogrid">
						<div class="row">
							<div class="col-1-4">
								<div class="wrap-col">
									<div class="sub-title">
										<h2>广告</h2>
									</div>
							<?php foreach ($content as $key => $value): ?>
								<?php if ($value['c_id']=='5'): ?>
									<?php if ($value['is_delete']=='0'): ?>
										<div class="item">
											<img src=<?php echo $value['img_url'] ?> />
										</div>
									<?php endif ?>
								<?php endif ?>
							<?php endforeach ?>		
								</div>
							</div>
							<div class="col-2-4">
								<div class="wrap-col">
									<div class="sub-title">
										<h2>即将举行的活动</h2>
									</div>
							<?php foreach ($content as $key => $value): ?>
								<?php if ($value['c_id']=='2'): ?>
									<?php if ($value['is_delete']=='0'): ?>
									<div class="row">
										<div class="item">
											<div class="col-1-3">
												<div class="item-date-box">
													<div class="item-caption-inner">
														<div class="item-caption-inner1">
															<h3><?php echo substr($value['datatime'],8,2) ?></h3>
															<span>jun,<?php echo substr($value['datatime'],0,4) ?></span>
														</div>
													</div>
												</div>
											</div>
											<div class="col-2-3">
												<div class="item-content">
													<a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><h3><?php echo $value['title'] ?></h3></a>
													<div class="info">发布于<?php echo $value['datatime'] ?> 在: <a href="#">即将举行的</a>, <a href="#">活动</a></div>
													<p><?php echo substr($value['content'],0,150) ?>....</p>
												</div>
											</div>
											<div class="clear"></div>
										</div>
									</div>
									<?php endif ?>
								<?php endif ?>
							<?php endforeach ?>		
								</div>
							</div>
							<div class="col-1-4">
								<div class="wrap-col">
									<div class="sub-title">
										<h2>最新帖子</h2>
									</div>
							<?php foreach ($content as $key => $value): ?>
								<?php if ($value['c_id']=='6'): ?>
									<?php if ($value['is_delete']=='0'): ?>	
									<div class="item">
										<img src=<?php echo $value['img_url'] ?> />
										<div class="item-content">
											<a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><h3><?php echo $value['title'] ?></h3></a>
											<p><?php echo substr($value['content'],0,50) ?>....</p>
										</div>
									</div>
									<?php endif ?>
								<?php endif ?>
							<?php endforeach ?>				
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
</section>

<!--////////////////////////////////////Footer-->
