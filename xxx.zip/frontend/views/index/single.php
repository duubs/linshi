 <?php 
         use yii\helpers\Url;
 ?>

<!--////////////////////////////////////Container-->
<section id="container" class="sub-page">
	<div class="wrap-container zerogrid">
		<div id="main-content" class="col-2-3">
			<div class="wrap-col">
				<div class="wrap-content">
					<article>
						<div class="art-header">
							
							<img src="images/slideshow-image1.jpg" />
						</div>
						<div class="art-content">
							<a href="#"><h3 style="font-size: 37px; line-height: 1.5;">前沿科技创业有限公司</h3></a>
							<div class="info">成立于2018年4月2日<a href="#"></a></div>
							<div class="excerpt"><p>前沿（北京）科技创业有限公司，
													我们为芸芸中小微创业者提供高品质的创业服务。我们走在创业的路上，也正因为如此，
													我们更懂得创业路上的艰辛与痛点。“全心全意为您服务”我们靠着这个理念前行，用互联网
													的力量，为更多的创业者提供一站式创业服务。
													我们注重服务质量，更注重用户体验。解决问题为了让在创业路上奋斗的人少走弯路。
													创业并不是疲惫不堪的身心苦旅，也非一劳永逸的美梦成真。创业，是一次“精神涅槃”
													当你在做一件美好的事时，我们坚信，终有一天，这个世界会因不懈努力创造美好的人们而改变。</p></div>
								<p>我们践行『精工之路』，品质为本、创新为魂，拥有端到端全系列自主知识产权的IP视频监控产品，包括IP摄像机、卡口电警、视频编解码器、NVR、监控网络、监控存储、监控平台、大屏，以及分销和SMB（中小商业客户）等产品，并面向不同行业提供解决方案。目前我们在中国30个省/市设立了办事机构，全球合作伙伴覆盖133个国家和地区，为客户提供近距离高品质的服务，为合作伙伴提供高效优质的支持。</p>
								<blockquote><p>加入我们前沿（北京）科技创业有限公司</p></blockquote>
								<p>我们希望这样的人加入我们的团队：
									做事认真、仔细、吃苦耐劳、责任心强：
									有良好的团队精神及团队协作力：
									有理想、有抱负，希望通过公司得以发展：
									能够为提升个人能力和推动企业发展付诸行动：
									不一定有学历，但一定要有学习力！
									在这里，你将会得到：
									持续成长的环境和空间：
									持续提升个人素质和技能：
									持续展现自我价值和人生梦想！</p>
								<h2>合作伙伴</h2>
								<p>企业与股东的关系、与顾客的关系、与员工的关系以及与社会的关系是一直以来被探讨的重要话题。而近些年来，企业与企业之间的关系越来越引起人们的重视，原因在于竞争的形势发生了变化，过去单个企业之间的竞争越来越变成了一群企业和另一群企业之间的竞争。如何找到更多的“朋友”，为竞争增添砝码，成了每一个企业需要思索的问题。这就不只是“行个礼、握握手”那样简单了。</p>
								<h2>海外渠道体系</h2>
								<p>90年代以后，一些欧美营销管理学家提出关系营销理论，对营销渠道的认识和管理逐渐深入。渠道关系是指组织间的关系，而不是组织内的关系，它发生在不同的法人之间。渠道关系理论以关系和联盟为重心的研究，认为由于利益之争，组织间合作常以失败而告终，为此渠道战略联盟等关系形式应运而生。1998年，辛古瓦、贝克尔研究了渠道关系绩效，提出了渠道合作关系能产生更高的利润，而且每一方都从联盟中得到更多利润的观点。2001年，斯特恩研究了渠道关系实质、选择和合作等内容，提出了渠道联盟等观点;奥德森提出了渠道关系的生命周期理论。渠道关系经过知晓、探索、拓展、忠诚和衰退及解散等生命期不同阶段的发展，可能进入一个相互忠诚的阶段。联盟是渠道关系中最高、最好的形式</p>
								<h2>服务资质认证</h2>
								<p>iso27001认证即“信息安全管理体系认证”，适用于任何企业或组织，不受地域、产业类别和公司规模限制。
									信息安全对每个企业或组织来说都是需要的，所以信息安全管理体系认证具有普遍的适用性，不受地域、产业类别和公司规模限制。从目前的获得认证的企业情况看，较多的是涉及电信、保险、银行、数据处理中心、IC制造和软件外包等行业。</p>
								<p>信息系统集成及服务是指从事信息网络系统、信息资源系统、信息应用系统的咨询设计、集成实施、运行维护等全生命周期活动，及总体策划、系统测评、数据处理存储、信息安全、运营等服务和保障业务领域。而系统集成服务资质的全称是计算机系统集成服务资质，是指中国电子信息行业联合会（以下称电子联合会）依据本管理办法和资质等级评定条件对从事信息系统集成及服务企业的综合能力和水平所进行的评价和认定。系统集成资质分为四个等级，分别从企业的综合能力和水平包括经营业绩、财务状况、信誉、管理能力、技术实力和人才实力等要素来进行审核认定。</p>
								<p><code>Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</code></p>
								<p>该平台获得的金融信息牌照，是由央行、银监会、北京市工商局、北京市金融工作局等多家政府机构核准颁发。该牌照获取难度相当大，目前全国范围内，获得此一资质牌照的只有该平台和另外一家互联网金融公司</p>
								<!-- <div class="note">
								  <ol>
									<li>Lorem ipsum</li>
									<li>Sit amet vultatup nonumy</li>
									<li>Duista sed diam</li>
								  </ol>
								  <div class="clear"></div>
								</div>
								<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p> -->
									<!-- <p style="font-size: 20px"><span><font color="blue">公司地址：</font></span>www.dxuubb.top <br>
									<span><font color="blue">公司名称：</font></span>前沿（北京）科技创业有限公司<br>
									<span><font color="blue">客服中心：</font></span>010-822096888（24小时服务）<br>
									<span><font color="blue">24小时咨询热线：</font></span>15035101602<br>
									<span><font color="blue">公司地址：</font></span>北京市海淀区</p> -->
						</div>
					</article>
				</div>
			</div>
		</div>
		<div id="sidebar" class="col-1-3">
			<div class="wrap-col">
				<div class="wrap-sidebar">
					<!---- Start Widget ---->
					<div class="widget wid-about">
						<div class="wid-header">
							<h5>关于我们</h5>
						</div>
				<?php foreach ($content as $key => $value): ?>
					<?php if ($value['c_id']=='8'): ?>
						<?php if ($value['is_delete']=='0'): ?>
						<div class="wid-content">
							<img src=<?php echo $value['img_url'] ?> />
							<p><?php echo $value['content'] ?></p>
						</div>
							<?php endif ?>
						<?php endif ?>
				<?php endforeach ?>
					</div>
					<!---- Start Widget ---->
					<div class="widget wid-post">
						<div class="wid-header">
							<h5>最新帖子</h5>
						</div>
						<div class="wid-content">
							
					<?php foreach ($content as $key => $value): ?>
						<?php if ($value['c_id']=='6'): ?>
							<?php if ($value['is_delete']=='0'): ?>		
							<div class="post">
								<img src=<?php echo $value['img_url'] ?> />
								<div class="wrapper">
								  <h5><a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><?php echo $value['title'] ?></a></h5>
								   <span>$25 - $26</span>
								</div>
							</div>
						<?php endif ?>
					<?php endif ?>
				<?php endforeach ?>
						</div>
					</div>
					<!---- Start Widget ---->
					<div class="widget wid-gallery">
						<div class="wid-header">
							<h5>画廊</h5>
						</div>
						<div class="wid-content">
								<?php foreach ($content as $key => $value): ?>
						<?php if ($value['c_id']=='7'): ?>
							<?php if ($value['is_delete']=='0'): ?>				
								<a href="<?php echo Url::to(['index/details']) ?>&id=<?php echo $value['id'] ?>"><img src=<?php echo $value['img_url'] ?>></a>
							<?php endif ?>
						<?php endif ?>
					<?php endforeach ?>	
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<!--////////////////////////////////////Footer-->
