<?php
namespace frontend\controllers;

use Yii;
use yii\web\Controller;


/**
 * 首页
 */
class IndexController extends Controller
{

    //public $layout = false; //不使用布局
    // public $layout = "main_one"; //设置使用的布局文件
    public $enableCsrfValidation = false; // post 提交时 关闭框架自带的防某种攻击

    /*
    *  网站首页
    */
    public function actionIndex()
    {
        $sqltwo="SELECT * FROM blogs";
        $blogs = Yii::$app->db->createCommand($sqltwo)->queryAll();
        return $this->render('index',['content'=>$this->actionJoint($blogs)]);
    }

    /*
     * 拼接图片路径
     */
    public function actionJoint($arr)
    {
        foreach ($arr as $k => $v) {
            $arr[$k]['img_url'] = '../../../backend/web/web/'.$v['img_url'];
        }
        return $arr;
    }

    /*
    * 博客
    */
    public function actionArchive()
    {
         $sqltwo="SELECT * FROM blogs";
        $blogs = Yii::$app->db->createCommand($sqltwo)->queryAll();
        
        return $this->render('archive',['content'=>$this->actionJoint($blogs)]);
    }


    /*
    * 关于
    */
    public function actionSingle()
    {
        $sqltwo="SELECT * FROM blogs";
        $blogs = Yii::$app->db->createCommand($sqltwo)->queryAll();
        return $this->render('single',['content'=>$this->actionJoint($blogs)]);
    }


    /*
    *   联系我们
    */
    public function actionContact()
    {
        return $this->render('contact');
    }

     /*
    *   添加联系发表意见
    */
    public function actionAddcontact()
    {
          $data = yii::$app->request->post(); //接收数据

        $sql="INSERT INTO simple (name,email,datatime,content) VALUES('".$data['name']."','".$data['email']."','".date('Y-m-d H:i:s')."','".$data['content']."')";
         Yii::$app->db->createCommand($sql)->execute();
         return $this->render('contact');
    }

    /*
    *   详情页
    */
    public function actionDetails()
    {
        $id = yii::$app->request->get('id');
        $sqltwo="SELECT * FROM blogs WHERE id=$id";
        $blogs = Yii::$app->db->createCommand($sqltwo)->queryAll();

        return $this->render('details',['content'=>$this->actionJoint($blogs)]);
    }
}
