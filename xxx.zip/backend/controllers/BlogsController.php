<?php
namespace backend\controllers;

use Yii;
use app\models\Blogs;
use app\models\Classify;
use app\models\UploadForm;
use yii\web\UploadedFile;
/*
 * 博客系统
 */
class BlogsController extends BaseController
{
    /**
     * @inheritdoc
     */
    public $enableCsrfValidation = false; //关闭csrf验证。
    public $layout = 'layout.php';
    public $imageFile;

    public function inits()
    {
        
    }

    public function actionDetails()
    {
        //接id
        $id = Yii::$app->request->get('id');
        $blogs = new Blogs();
        // $data = $blogs->find()->where(['id'=>$id])->asArraY()->one();
        $data = $blogs->find()->select('*')->innerJoin('classify','blogs.c_id = classify.c_id')->where(['id'=>$id])->asArraY()->one();
        return $this->render('details',['data'=>$data]);
    }


    // 博客列表
    public function actionList()
    {
        // 实例化博客表
        $blogs = new Blogs();
        //查询所有数据
        $data = $blogs->find()->select('*')->innerJoin('classify','blogs.c_id=classify.c_id')->asArraY()->all();
        // 原生sql 两表联查
        // $data = Yii::$app->db->createCommand('SELECT * FROM `blogs` INNER JOIN `classify` ON blogs.c_id=classify.c_id')->queryAll();
        return $this->render('list',['data'=>$data]);
    }

    //  博客添加
    public function actionAdd()
    {
        // 分类列表
        $classify = new  Classify();
        $cate = $classify->find()->asArraY()->all();
        return $this->render('add',['cate'=>$cate]);
    }

    // 博客添加入库  （文件上传）
    public function actionUpload()
    {
        if(Yii::$app->request->isPost) {
            $post =  Yii::$app->request->post();
            $img = UploadedFile::getInstanceByName('img');
            $post['img'] = '../upload/'.$img->name;
            $file = $img->saveAs('./upload/'.$img->name);

            $blogs = new Blogs;
            $blogs->title        = $post['title'];
            $blogs->datatime    = date('Y-m-d H:i:s');
            $blogs->c_id          = $post['c_id'];
            $blogs->img_url         = $post['img'];
            $blogs->content         = $post['content'];
            $blogs->is_delete       = $post['is_delete'];
            $res = $blogs->save();
            if ($res && $file) {
                $blogs = new Blogs();
                $data = $blogs->find()->select('*')->innerJoin('classify','blogs.c_id=classify.c_id')->asArraY()->all();
                return $this->render('list',['data'=>$data]);
            }
        }
    }

    // 博客删除
    public function actionDel()
    {
        $id =  Yii::$app->request->get('id');
        $blogs = new Blogs;
        $data = $blogs->find()->where(['id'=>$id])->one();
        $res = $data->delete();
        if($res){
            echo '删除成功';
        }else{
            echo '滚犊子';
        }
    }

    // 博客修改
    public function actionUpd()
    {
        // 接收要修改的博客id
        $id =  Yii::$app->request->get('id');
        $blogs = new Blogs();
        $data = $blogs->find()->select('*')->innerJoin('classify','blogs.c_id = classify.c_id')->where(['id'=>$id])->asArraY()->one();
        $cate = new Classify();
        $cate = $cate->find()->asArraY()->all();
        return $this->render('upd',['data'=>$data,'cate'=>$cate]);
    }

    // 执行修改
    public function actionUpd_do()
    {
        // 接收修改后的数据
        $post = Yii::$app->request->post();
        $id = $post['id'];
        // 接收修改后的图片信息
        $img = UploadedFile::getInstanceByName('img');
        $post['img_url'] = '../upload/'.$img->name;
        $file = $img->saveAs('./upload/'.$img->name);
        // 判定如果img为空
        if (!$img) {
            unset($post['img']);
        }
        $db = Yii::$app->db ->createCommand()->update('blogs', $post,'id='.$id)->execute();
        if ($db ) {
            echo "<script>alert('修改成功');location.href='../index.php?r=blogs/list';</script>";
        }
    }
}
