<?php
namespace backend\controllers;

use Yii;
use app\models\Simple;
/*
 * 用户建议类
 */
class SuggestController extends BaseController
{
    public $layout = 'layout.php';

    public function inits()
    {

    }

    /**
     * 建议列表
     */
    public function actionRelease()
    {
        $list = Simple::find()->where(['is_delete'=>0])->asArray()->all();
        return $this->render('release',['list'=>$list]);
    }
    /**
     * 详情
     */
    public function actionDetails()
    {
        //接id
        $id = Yii::$app->request->get('id');
        $simple = new Simple();
        $data = $simple->find()->select('*')->where(['id'=>$id])->asArraY()->one();
        $list = $simple->find()->where(['id'=>$id])->one();
        $list->is_read = 1;
        $list->save();
        return $this->render('details',['data'=>$data]);
    }
    /**
     * 删除
     */
    public function actionDel()
    {
        if ($id = Yii::$app->request->get('id')){
            $list = Simple::find()->where(['id'=>$id])->one();
            $list->is_delete = 1;
            $list->save();
            return $this->redirect(['release']);
        }

    }

}