<?php
namespace backend\controllers;

use Yii;
use app\models\Admin;

/*
 * 管理员账号权限管理系统
 */
class AdminController extends BaseController
{

    public $layout = 'layout.php'; //引用公共模板
    public $request;

    public function inits()
    {
        $this->request = Yii::$app->request;
    }

    /**
     *  首页
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    /**
     * 添加账号
     */
    public function actionAddaccount()
    {
        if ($post = $this->request->post()){
            $Admin = new Admin;
            $Admin->name        = $post['name'];
            $Admin->pwd         = $post['pwd'];
            $Admin->nickname    = $post['nickname'];
            $Admin->sex         = $post['sex'];
            $Admin->datatime    = date('Y-m-d H:i:s');
            if ($Admin->save()) {
                echo "<script>alert('添加成功');</script>";
                return $this->redirect(['index']);
            } else {
                echo "<script>alert('添加失败');</script>";
            }
        }
        return $this->render('addaccount');
    }

    /**
     * 修改账号
     */
    public function actionUp()
    {
        $list = [];
        if ($id = $this->request->get('id')){
            $list = Admin::find()->where(['id'=>$id])->asArray()->one();
        }
        if ($post = $this->request->post()){
            $list = Admin::find()->where(['id'=>$post['id']])->one();
            $list->name        = $post['name'];
            $list->pwd         = $post['pwd'];
            $list->nickname    = $post['nickname'];
            $list->sex         = $post['sex'];
            $list->datatime    = date('Y-m-d H:i:s');
            if ($list->save()) {
                echo "<script>alert('修改成功');</script>";
                return $this->redirect(['account']);
            } else {
                echo "<script>alert('修改失败');</script>";
            }
        }

        return $this->render('up',['list'=>$list]);
    }

    /**
     * 账号删除
     */
    public function actionDel()
    {
        if ($id = $this->request->get('id')){
            if (Admin::deleteAll(['id'=>$id])) {
                echo "<script>alert('删除成功');</script>";
            } else {
                echo "<script>alert('删除失败');</script>";
            }
            return $this->redirect(['account']);
        }

    }

    /**
     * 账号列表
     */
    public function actionAccount()
    {
        $list = Admin::find()->asArray()->all();
        return $this->render('account',['list'=>$list]);
    }

    /**
     * 密码设定
     */
    public function actionChange()
    {
        if ($post = $this->request->post()){
            if ($post['pwd'] == $post['pwds']){
                $userid = Yii::$app->session->get('userid');
                $list = Admin::find()
                    ->where(['id'=>$userid,'pwd'=>$post['pass']])
                    ->one();

                if ($list){
                    $list->pwd = $post['pwd']; //修改属性值
                    if ($list->save()){
                        Yii::$app->session->remove('userid');
                        echo "<script>alert('修改成功');</script>";
                        return $this->redirect(['/login/cuo']);
                    }else{
                        echo "<script>alert('修改失败');</script>";
                    }
                }else{
                    echo "<script>alert('原始密码错误');</script>";
                }

            }

        }

        return $this->render('change');
    }

    /**
     * 用户权限
     */
    public function actionCopy()
    {
        return $this->render('copy');
    }

}