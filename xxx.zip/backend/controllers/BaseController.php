<?php
namespace backend\controllers;

use Yii;
use yii\web\Controller;
use app\models\Admin;
/*
 * 管理员账号权限管理系统
 */
class BaseController extends Controller
{

    public $enableCsrfValidation = false; //关闭csrf验证。

    public function init()
    {
        $session = Yii::$app->session;
        $userid = $session->get('userid');
        if(!$userid){

            $request = Yii::$app->request;
            $post = $request->post();

            if (empty($post)){
                return $this->redirect(['/login/cuo']);
            }

            $array = Admin::find()
                ->where(['name' => $post['username'], 'pwd' => $post['password']])
                ->asArray()
                ->one();
            if (!$array){
                return $this->redirect(['/login/cuo']);
            }
            YII::$app->session->open();
            YII::$app->session->set('userid', $array['id']);
        }

        $this->inits();
    }
}
