<?php
namespace backend\controllers;

/*
*   后台登录
*/
class LoginController extends BaseController
{
    /**
     * @inheritdoc
     */
    public $layout = false;

    public function inits()
    {

    }

    public function actionIndex()
    {

        return $this->render('index');
    }

    public  function  actionCuo()
    {

        return $this->render('cuo');
    }
}