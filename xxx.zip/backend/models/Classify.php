<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "classify".
 *
 * @property integer $c_id
 * @property string $name
 * @property integer $is_delete
 */
class Classify extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'classify';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['is_delete'], 'integer'],
            [['name'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'c_id' => 'C ID',
            'name' => '分类名称',
            'is_delete' => '是否删除',
        ];
    }
}
