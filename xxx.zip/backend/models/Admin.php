<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "admin".
 *
 * @property integer $id
 * @property string $name
 * @property string $pwd
 * @property string $nickname
 * @property integer $sex
 * @property string $datatime
 * @property string $j_id
 * @property integer $is_use
 */
class Admin extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'admin';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['sex', 'is_use'], 'integer'],
            [['datatime'], 'safe'],
            [['name', 'nickname'], 'string', 'max' => 50],
            [['pwd'], 'string', 'max' => 32],
            [['j_id'], 'string', 'max' => 200],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => '用户账号',
            'pwd' => '用户密码',
            'nickname' => '昵称',
            'sex' => '性别(0女1男)',
            'datatime' => '创建时间',
            'j_id' => '权限id',
            'is_use' => '是否启用',
        ];
    }
}
