<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "simple".
 *
 * @property integer $id
 * @property string $name
 * @property string $email
 * @property integer $is_read
 * @property integer $is_reply
 * @property integer $is_accept
 * @property string $datatime
 * @property integer $is_delete
 * @property string $content
 */
class Simple extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'simple';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['is_read', 'is_reply', 'is_accept', 'is_delete'], 'integer'],
            [['datatime'], 'safe'],
            [['content'], 'string'],
            [['name', 'email'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => '用户名称',
            'email' => '用户邮箱',
            'is_read' => '是否阅读',
            'is_reply' => '是否回复',
            'is_accept' => '是否采纳',
            'datatime' => '生成时间',
            'is_delete' => '是否删除',
            'content' => '内容',
        ];
    }
}
