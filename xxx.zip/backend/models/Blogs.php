<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "blogs".
 *
 * @property integer $id
 * @property string $title
 * @property string $datatime
 * @property integer $c_id
 * @property string $content
 * @property string $img_url
 * @property integer $is_delete
 */
class Blogs extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'blogs';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['datatime'], 'safe'],
            [['c_id', 'is_delete'], 'integer'],
            [['content'], 'string'],
            [['title'], 'string', 'max' => 50],
            [['img_url'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => '博客id',
            'title' => '标题',
            'datatime' => '发布时间',
            'c_id' => '分类id',
            'content' => '内容',
            'img_url' => '图片路径',
            'is_delete' => '是否删除',
        ];
    }
}
