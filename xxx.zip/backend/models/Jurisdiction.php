<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "jurisdiction".
 *
 * @property integer $id
 * @property string $controller
 * @property string $action
 * @property string $name
 * @property integer $r_id
 * @property string $datatime
 * @property integer $is_show
 * @property integer $is_use
 */
class Jurisdiction extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'jurisdiction';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['r_id', 'is_show', 'is_use'], 'integer'],
            [['datatime'], 'safe'],
            [['controller', 'action'], 'string', 'max' => 20],
            [['name'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'controller' => '控制器',
            'action' => '方法',
            'name' => '权限名称',
            'r_id' => '父级id',
            'datatime' => '创建时间',
            'is_show' => '是否显示',
            'is_use' => '是否启用',
        ];
    }
}
