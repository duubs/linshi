<script type="text/javascript">
    alert("账号或密码错误");
    top.location='index.php';
</script>