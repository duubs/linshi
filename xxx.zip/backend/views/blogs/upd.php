<?php
use yii\widgets\ActiveForm;
?>

<center style="margin-top: 20px;">
	<form action="../index.php?r=blogs/upd_do"  method="post" enctype="multipart/form-data" >
	<table>
		<tr>
			<td>博客标题：</td>
			<td><input type="text" name="title" value="<?=$data['title']?>"></td>
		</tr>
		<tr>
			<td>博客分类：</td>
			<td>
				<select name="c_id">
					<option value="null">-- 请选择 --</option>
					<?php foreach($cate as $k => $v){?>
						<?php if($v['c_id'] == $data['c_id']) {?>
						<option value="<?=$v['c_id']?>" selected><?=$v['name']?></option>
						<?php } else{ ?>
						<option value="<?=$v['c_id']?>"><?=$v['name']?></option>
						<?php }?>
					<?php  }?>
				</select>
			</td>
		</tr>
		<tr>
			<td>博客内容：</td>
			<td><textarea name="content" cols="30" rows="10"><?=$data['content']?></textarea></td>
		</tr>
		<tr>
			<td>缩略图：</td>
			<td><img style="width: 40px; height: 40px;" src="<?=$data['img_url']?>"><input type="file" name='img'></td>
		</tr>
		<tr>
			<td>是否上架：</td>
			<td>
				<?php if ($data['is_delete'] == 1) {?>
				<input type="radio" name="is_delete" value="0">是
				<input type="radio" name="is_delete" value="1" checked>否
				<?php } else {?>
				<input type="radio" name="is_delete" value="0" checked>是
				<input type="radio" name="is_delete" value="1">否
				<?php }?>
			</td>
		</tr>
		<tr>
			<input type="hidden" value="<?=$data['id']?>" name="id">
			<td> <input type="submit" value="提交"></td>
		</tr>
	</table>
	</form>
</center>